# Uncountable Frontend by Ifaz

Built using React, Typescript and Vite.
User can upload their JSON document in the provided format and see the data on a Scatter Plot, with options for specifying the inputs and the output they want to see.

For displaying the Scatter graph I could had chosen other libraries such as D3 and Chart.js. But based on research it seemed Rechart was the easiest and simplest to work with, so choose that given the time condition of this project.

If I was to make a fully fledge data analysis webapp, I would choose D3 as it gives greater control over what you can do with the graphs


## How to Run

1. Install the dependencies:
  ```sh
  npm install
  ```

2. Start the development server:
  ```sh
  npm run dev
  ```


## How things work

When user uploads file, it is handled by FileUploader which puts it into a easy to work with form "Experiment". The list is then stored locally so that data is not lost incase you reload or go back.

Afterwards user can go to the ScatterPlot page which is made of two main components:
1. ControlPanel: Allows user to select properties for the ScatterGraph, which are then passed to the ScatterPlot component using the set method when user presses generate. This causes the ScatterPlotChart to reload

2. ScatterPlotChart: The actual component which represents the ScatterPlot. It is built using Rechart. The data passed from ControlPanel is processed and then used to create the Scatter components



## Dependencies

- `@types/styled-components`: TypeScript definitions for styled-components.
- `react`: React library.
- `react-dom`: React DOM library.
- `react-router-dom`: React Router library.
- `recharts`: Charting library for React.
- `styled-components`: CSS-in-JS library.
