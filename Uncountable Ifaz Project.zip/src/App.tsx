import styled from "styled-components";
import { BrowserRouter as Router, Routes, Route, useNavigate } from "react-router-dom";

import {
  saveToLocalStorage,
} from "./utils/dataParser";
import { useState } from "react";
import { ExperimentDataset } from "./types/dataset";
import FileUploader from "./components/FileUploader";
import ScatterPlot from "./components/ScatterPlot";

const AppContainer = styled.div`
  max-width: 95%;
  margin: 0 auto;
  padding: 20px;
  font-family: Arial, sans-serif;
  text-align: center;
`;

const AppTitle = styled.h1`
  color: #333;
  margin-bottom: 20px;
`;



const UploadInstructions = styled.p`
  font-size: 18px;
  color: #666;
  margin-bottom: 20px;
`;

const NavigateButton = styled.button`
  background-color: #007bff;
  color: white;
  padding: 10px 20px;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  font-size: 16px;
  margin-top: 20px;

  &:hover {
    background-color: #0056b3;
  }
`;

const App: React.FC = () => {
  const [processedData, setProcessedData] = useState<ExperimentDataset | null>(null);
  const navigate = useNavigate(); 

  const handleNavigate = () => {
    navigate("/scatterplot");
  };

  const handleSetProcessedData = (data: ExperimentDataset | null) => {
    setProcessedData(data);
    if (data) {
      saveToLocalStorage("processedData", data);
    }
  };

  return (
    <Routes>
      <Route
        path="/"
        element={
          <AppContainer>
            <AppTitle>Welcome to Uncountable Ifaz's Project</AppTitle>
            <UploadInstructions>
              Please upload your JSON dataset to get started.
            </UploadInstructions>
            <FileUploader setProcessedData={handleSetProcessedData} />
            {processedData && (
              <div>
                <h2>Data Uploaded Successfully</h2>
                <NavigateButton onClick={handleNavigate}>Go to ScatterPlot</NavigateButton>
              </div>
            )}
          </AppContainer>
        }
      />
      <Route path="/scatterplot" element={<ScatterPlot/>} />
    </Routes>
  );
};

export default App;
