export interface Experiment {
    name: string;
    inputs: Record<string, number>;
    outputs: Record<string, number>;
}
  
export type ExperimentDataset = Experiment[];

export interface GraphDataEntry {
    input: number;
    output: number;
}

export interface GraphDataCollection {
    inputs: string[];
    output: string;
    xRange: [number, number];
    yRange: [number, number];
    points: GraphDataEntry[][];
}