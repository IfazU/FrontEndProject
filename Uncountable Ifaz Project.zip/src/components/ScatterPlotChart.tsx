import React from "react";
import {
  ScatterChart,
  Scatter,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";
import { GraphDataCollection } from "../types/dataset";

interface ScatterPlotProps {
  graphData: GraphDataCollection;
}

const ScatterPlotChart: React.FC<ScatterPlotProps> = ({ graphData }) => {
  const getRandomColor = () => {
    const letters = "0123456789ABCDEF";
    let color = "#";
    for (let i = 0; i < 6; i++) {
      color += letters[Math.floor(Math.random() * 16)];
    }
    return color;
  };

  return (
    <ResponsiveContainer width="100%" height="100%">
      <ScatterChart
        width={window.innerWidth * 0.7}
        height={window.innerHeight * 0.7}
        margin={{ top: 20, right: 20, bottom: 20, left: 20 }}
      >
        <CartesianGrid />
        <XAxis
          dataKey="x"
          type="number"
          domain={graphData.xRange}
          name="Quantity"
        />
        <YAxis
          dataKey="y"
          type="number"
          domain={graphData.yRange}
          name={graphData.output}
        />
        <Tooltip
          cursor={{ strokeDasharray: "3 3" }}
          content={({ payload }) => {
            if (payload && payload.length) {
              const point = payload[0].payload;
              return (
                <div style={{ backgroundColor: "white", padding: "5px", border: "1px solid #ccc" }}>
                  <p>{`Name: ${point.name}`}</p>
                  <p>{`x: ${point.x}`}</p>
                  <p>{`y: ${point.y}`}</p>
                </div>
              );
            }
            return null;
          }}
        />
        <Legend />
        {graphData.points.map((dataPoints, index) => {
          const filteredData = dataPoints
            .map((point) => ({
              x: point.input,
              y: point.output,
              name: graphData.inputs[index], // Add name to each point
            }))
            .filter(
              (point) =>
                point.x >= graphData.xRange[0] &&
                point.x <= graphData.xRange[1] &&
                point.y >= graphData.yRange[0] &&
                point.y <= graphData.yRange[1]
            );

          return (
            <Scatter
              key={index}
              name={graphData.inputs[index]}
              data={filteredData}
              fill={getRandomColor()}
            />
          );
        })}
      </ScatterChart>
    </ResponsiveContainer>
  );
};

export default ScatterPlotChart;
