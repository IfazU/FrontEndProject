import {
  ExperimentDataset,
  GraphDataCollection,
  GraphDataEntry,
} from "../types/dataset";
import { getFromLocalStorage } from "../utils/dataParser";
import React, { useState } from "react";
import styled from "styled-components";

interface ControlPanelProsp {
  setGraphData: (data: GraphDataCollection) => void;
}

const Container = styled.div`
  display: flex;
  flex-direction: column;
  padding: 5px;
  gap: 10px; 
  font-size: 14px;
`;
const Header = styled.h1`
  font-size: 24px;
`;

const ScrollableWindow = styled.div`
  max-height: 150px;
  overflow-y: auto;
  border: 1px solid black;
  padding: 10px;
  margin-top: 10px;
`;

const InputTag = styled.div<{ selected: boolean }>`
  padding: 5px;
  cursor: pointer;
  background-color: ${(props) => (props.selected ? "darkgray" : "lightgray")};
  margin-bottom: 5px;
  border-radius: 5px;
  &:hover {
    background-color: ${(props) => (props.selected ? "gray" : "silver")};
  }
`;

const WindowsContainer = styled.div`
  display: flex;
  justify-content: space-between;
  gap: 20px;
`;

const RangeContainer = styled.div`
  margin-top: 5px; 
  display: flex;
  align-items: center;
`;

const RangeLabel = styled.h3`
  margin-right: 10px;
  font-size: 14px; 
`;

const RangeInput = styled.input`
  width: 50px;
  margin: 0 5px;
`;

const BlueButton = styled.button`
  margin-top: 10px; 
  padding: 10px 20px;
  background-color: #007bff;
  color: white;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  font-size: 14px;
  &:hover {
    background-color: #0056b3;
  }
`;


const ControlPanel: React.FC<ControlPanelProsp> = ({ setGraphData }) => {
  const data: ExperimentDataset = getFromLocalStorage("processedData");
  const inputs: string[] = Object.keys(data[0].inputs);
  const outputs: string[] = Object.keys(data[0].outputs);
  const [selectedInputs, setSelectedInputs] = useState<string[]>([]);
  const [selectedOutput, setSelectedOutput] = useState<string>("");
  const [xAxisRange, setXAxisRange] = useState<[number, number]>([0, 50]);
  const [yAxisRange, setYAxisRange] = useState<[number, number]>([0, 50]);

  const handleInputClick = (input: string) => {
    setSelectedInputs((prevSelectedInputs) =>
      prevSelectedInputs.includes(input)
        ? prevSelectedInputs.filter((i) => i !== input)
        : [...prevSelectedInputs, input]
    );
  };

  const handleOutputClick = (output: string) => {
    setSelectedOutput(output === selectedOutput ? "" : output);
  };

  const handleXAxisRangeChange = (index: number, value: number) => {
    const newRange = [...xAxisRange] as [number, number];
    newRange[index] = value;
    setXAxisRange(newRange);
  };

  const handleYAxisRangeChange = (index: number, value: number) => {
    const newRange = [...yAxisRange] as [number, number];
    newRange[index] = value;
    setYAxisRange(newRange);
  };

  const handleGenerateGraph = () => {
    if (selectedInputs.length === 0 || selectedOutput === "") {
      alert("Please select both inputs and output.");
      return;
    }

    const graphDataPoints: GraphDataEntry[][] = selectedInputs.map((input) => {
      return data.map((entry) => ({
        input: entry.inputs[input],
        output: entry.outputs[selectedOutput],
      }));
    });

    const graphDataCollection: GraphDataCollection = {
      inputs: selectedInputs,
      output: selectedOutput,
      xRange: xAxisRange,
      yRange: yAxisRange,
      points: graphDataPoints,
    };

    setGraphData(graphDataCollection);
  };

  return (
    <Container>
      <Header>Control Panel</Header>
      <WindowsContainer>
        <div>
          <h3>Select Inputs</h3>
          <ScrollableWindow>
            {inputs.map((input) => (
              <InputTag
                key={input}
                onClick={() => handleInputClick(input)}
                selected={selectedInputs.includes(input)}
              >
                {input}
              </InputTag>
            ))}
          </ScrollableWindow>
        </div>
        <div>
          <h3>Select Output</h3>
          <ScrollableWindow>
            {outputs.map((output) => (
              <InputTag
                key={output}
                onClick={() => handleOutputClick(output)}
                selected={selectedOutput === output}
              >
                {output}
              </InputTag>
            ))}
          </ScrollableWindow>
        </div>
      </WindowsContainer>
      <RangeContainer>
        <RangeLabel>Set X-Axis Range</RangeLabel>
        <RangeInput
          type="number"
          min="0"
          value={xAxisRange[0]}
          onChange={(e) => handleXAxisRangeChange(0, Number(e.target.value))}
        />
        <RangeInput
          type="number"
          min="0"
          value={xAxisRange[1]}
          onChange={(e) => handleXAxisRangeChange(1, Number(e.target.value))}
        />
      </RangeContainer>
      <RangeContainer>
        <RangeLabel>Set Y-Axis Range</RangeLabel>
        <RangeInput
          type="number"
          min="0"
          value={yAxisRange[0]}
          onChange={(e) => handleYAxisRangeChange(0, Number(e.target.value))}
        />
        <RangeInput
          type="number"
          min="0"
          value={yAxisRange[1]}
          onChange={(e) => handleYAxisRangeChange(1, Number(e.target.value))}
        />
      </RangeContainer>
      <BlueButton onClick={() => handleGenerateGraph()}>
        Generate Graph
      </BlueButton>
    <BlueButton onClick={() => window.location.href = "/"}>
      Back
    </BlueButton>
    </Container>
  );
};

export default ControlPanel;
