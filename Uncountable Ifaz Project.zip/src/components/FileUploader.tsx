import { ExperimentDataset } from "../types/dataset";
import { parseExperimentDataset } from "../utils/dataParser";

interface FileUploaderProps {
  setProcessedData: (data: ExperimentDataset | null) => void;
}

const FileUploader: React.FC<FileUploaderProps> = ({ setProcessedData }) => {

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (readFile) => {
        try {
          const content = readFile.target?.result as string;
          const jsonData = JSON.parse(content);
          const parsedData = parseExperimentDataset(jsonData);
          setProcessedData(parsedData);
        } catch (error) {
          console.error("Error parsing JSON file:", error);
          setProcessedData(null);
        }
      };
      reader.readAsText(file);
    }
  };

  return (
    <div>
      <input
        id="file-upload"
        type="file"
        accept=".json"
        onChange={handleFileChange}
      />
    </div>
  );
};

export default FileUploader;
