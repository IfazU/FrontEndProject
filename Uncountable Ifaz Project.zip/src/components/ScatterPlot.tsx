import React, { useState } from "react";
import styled from "styled-components";
import { GraphDataCollection } from "../types/dataset";
import ControlPanel from "./ControlPanel";
import ScatterPlotChart from "./ScatterPlotChart";

const Container = styled.div`
    display: flex;
    width: 100%;
    height: 97vh;
`;

const ControlsContainer = styled.div`
  flex: 1;
  background-color: rgb(240, 234, 234);
  padding: 20px;
  overflow-y: auto;
`;

const GraphContainer = styled.div`
  flex: 3;
  background-color: #fff;
  display: flex;
  justify-content: center;
  align-items: center;
`;

const ScatterPlot: React.FC = () => {
  const [graphData, setGraphData] = useState<GraphDataCollection | null>(null);
  return (
    <Container>
      <ControlsContainer>
        <ControlPanel
          setGraphData={setGraphData}
        />
      </ControlsContainer>
      <GraphContainer>
        {graphData && <ScatterPlotChart graphData={graphData} />}
      </GraphContainer>
    </Container>
  );
};

export default ScatterPlot;
